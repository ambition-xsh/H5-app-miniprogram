<template>
	<view>占位组件，请勿使用；如需下载示例项目，请使用【下载插件并导入HBuilderX】或【使用 HBuilderX 导入示例项目】或【下载示例项目ZIP】</view>
</template>
<script>
</script>
<style>
</style>
